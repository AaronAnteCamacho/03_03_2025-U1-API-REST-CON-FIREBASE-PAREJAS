const admin = require("firebase-admin");
const serviceAccount = require("../fir-3cf0b-firebase-adminsdk-fbsvc-da2e8c9cce.json");

// Inicializar Firebase
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();
const tasksCollection = db.collection("tasks");

module.exports = { tasksCollection };