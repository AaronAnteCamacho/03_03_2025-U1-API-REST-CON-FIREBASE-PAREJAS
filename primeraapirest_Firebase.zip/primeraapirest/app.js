const express = require('express');
const app = express();
const taskRoutes = require('./routers/taskRoutes'); // Importar el enrutador

// Middleware para parsear JSON
app.use(express.json());

// Montar el enrutador bajo la ruta /tasks
app.use('/tasks', taskRoutes);

// Ruta de prueba
app.get('/', (req, res) => {
  res.send('¡Bienvenido a la API de tareas!');
});

// Iniciar el servidor
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});